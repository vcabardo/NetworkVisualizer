Install Packages:
npm install express
npm install mongoose
npm install socket.io
npm install vis-network
npm install ejs
npm install fs
npm install formidable
npm i auto-save